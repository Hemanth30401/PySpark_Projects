******# Interview Explanation

I built a personal data engineering project using Azure Databricks, PySpark,
and Delta Lake. I ingest raw customer and transaction CSV files into a Bronze
Delta table, then use PySpark to clean, validate, standardize, and deduplicate
the data in the Silver layer. In the Gold layer, I join customer and transaction
data and create business-level daily customer metrics. I use Delta MERGE for
incremental inserts and updates instead of reprocessing the complete dataset.
Finally, I query the Gold Delta tables with SQL and optionally write the Gold
result to a SQL database for reporting.

## 30-second version

"I built a Medallion architecture project in Databricks using PySpark and
Delta Lake. Raw CSV data is loaded into Bronze, transformed and validated in
Silver, and aggregated into Gold. I used Delta MERGE for incremental processing,
schema enforcement and data-quality checks, and used Spark optimizations such
as broadcast joins. The Gold data can then be queried with SQL or exported to
a SQL database for reporting."

## Key interview questions

### Why Delta Lake?
It provides reliable table operations, schema enforcement, transaction history,
and MERGE support for incremental processing.

### Why Bronze/Silver/Gold?
Bronze preserves raw input, Silver provides clean trusted data, and Gold
provides business-ready data.

### Why MERGE?
MERGE allows new records to be inserted and existing records to be updated
using a business key without rebuilding the whole target table.

### Why broadcast join?
If one side of a join is small enough, broadcasting it can reduce shuffle and
improve Spark join performance.

### What would you add for production?
Unity Catalog, secrets/key management, orchestration, monitoring, CI/CD,
parameterized environments, data-quality frameworks, and proper access control.
