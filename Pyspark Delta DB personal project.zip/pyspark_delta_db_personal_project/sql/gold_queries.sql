-- Query Gold Delta table from a Databricks SQL warehouse.
SELECT
    customer_id,
    name,
    country,
    segment,
    transaction_date,
    transaction_count,
    total_amount,
    average_amount
FROM delta.`/mnt/demo/pyspark_delta/gold/customer_daily_summary`
ORDER BY transaction_date, customer_id;

-- Example business question
SELECT
    country,
    SUM(total_amount) AS total_sales
FROM delta.`/mnt/demo/pyspark_delta/gold/customer_daily_summary`
GROUP BY country
ORDER BY total_sales DESC;
