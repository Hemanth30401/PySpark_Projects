# Simple interview/demo checklist.
def test_expected_layers():
    layers = ["bronze", "silver", "gold"]
    assert layers == ["bronze", "silver", "gold"]
