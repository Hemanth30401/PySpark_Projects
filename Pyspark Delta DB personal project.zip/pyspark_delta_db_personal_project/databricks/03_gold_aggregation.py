from pyspark.sql import functions as F

base = "/mnt/demo/pyspark_delta"

customers = spark.read.format("delta").load(f"{base}/silver/customers")
transactions = spark.read.format("delta").load(f"{base}/silver/transactions")

gold = (
    transactions
    .join(F.broadcast(customers), "customer_id", "left")
    .groupBy(
        "customer_id",
        "name",
        "country",
        "segment",
        "transaction_date"
    )
    .agg(
        F.count("*").alias("transaction_count"),
        F.sum("amount").alias("total_amount"),
        F.avg("amount").alias("average_amount")
    )
)

gold.write.format("delta").mode("overwrite").partitionBy("transaction_date").save(
    f"{base}/gold/customer_daily_summary"
)
