from pyspark.sql import functions as F

base = "/mnt/demo/pyspark_delta"

customers = (
    spark.read.option("header", True).option("inferSchema", True)
    .csv("/dbfs/FileStore/project/data/raw/customers.csv")
)

transactions = (
    spark.read.option("header", True).option("inferSchema", True)
    .csv("/dbfs/FileStore/project/data/raw/transactions.csv")
    .withColumn("ingestion_time", F.current_timestamp())
)

customers.write.format("delta").mode("overwrite").save(f"{base}/bronze/customers")
transactions.write.format("delta").mode("overwrite").save(f"{base}/bronze/transactions")
