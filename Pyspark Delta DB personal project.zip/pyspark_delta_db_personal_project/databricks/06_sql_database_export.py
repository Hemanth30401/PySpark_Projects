# Optional: write Gold data to a SQL database using JDBC.
# Keep credentials in Databricks secrets; never hard-code passwords.

gold = spark.read.format("delta").load(
    "/mnt/demo/pyspark_delta/gold/customer_daily_summary"
)

jdbc_url = "jdbc:sqlserver://<server>.database.windows.net:1433;database=<database>"

(
    gold.write
    .format("jdbc")
    .option("url", jdbc_url)
    .option("dbtable", "dbo.CustomerDailySummary")
    .option("user", "<secret-managed-user>")
    .option("password", "<secret-managed-password>")
    .mode("append")
    .save()
)
