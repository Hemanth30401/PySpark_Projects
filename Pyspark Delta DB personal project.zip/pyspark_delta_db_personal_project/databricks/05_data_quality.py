from pyspark.sql import functions as F

base = "/mnt/demo/pyspark_delta"
df = spark.read.format("delta").load(f"{base}/silver/transactions")

null_ids = df.filter(F.col("transaction_id").isNull()).count()
negative_amounts = df.filter(F.col("amount") < 0).count()
duplicate_ids = (
    df.groupBy("transaction_id")
      .count()
      .filter(F.col("count") > 1)
      .count()
)

if null_ids == 0 and negative_amounts == 0 and duplicate_ids == 0:
    print("DATA QUALITY: PASS")
else:
    print("DATA QUALITY: FAIL")
    print({
        "null_transaction_ids": null_ids,
        "negative_amounts": negative_amounts,
        "duplicate_transaction_ids": duplicate_ids
    })
