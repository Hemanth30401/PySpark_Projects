from pyspark.sql import functions as F

base = "/mnt/demo/pyspark_delta"

customers = spark.read.format("delta").load(f"{base}/bronze/customers")
transactions = spark.read.format("delta").load(f"{base}/bronze/transactions")

customers_silver = (
    customers
    .withColumn("customer_id", F.trim("customer_id"))
    .withColumn("name", F.trim("name"))
    .withColumn("country", F.upper(F.trim("country")))
    .filter(F.col("customer_id").isNotNull())
    .dropDuplicates(["customer_id"])
)

transactions_silver = (
    transactions
    .withColumn("transaction_id", F.trim("transaction_id"))
    .withColumn("customer_id", F.trim("customer_id"))
    .withColumn("transaction_date", F.to_date("transaction_date"))
    .withColumn("amount", F.col("amount").cast("decimal(18,2)"))
    .withColumn("transaction_type", F.upper(F.trim("transaction_type")))
    .filter(F.col("transaction_id").isNotNull())
    .filter(F.col("customer_id").isNotNull())
    .filter(F.col("amount") >= 0)
    .dropDuplicates(["transaction_id"])
)

customers_silver.write.format("delta").mode("overwrite").save(f"{base}/silver/customers")
transactions_silver.write.format("delta").mode("overwrite").partitionBy("transaction_date").save(f"{base}/silver/transactions")
