from delta.tables import DeltaTable
from pyspark.sql import functions as F

base = "/mnt/demo/pyspark_delta"
target_path = f"{base}/silver/transactions"

# Example: read a new batch from a landing location.
new_data = (
    spark.read.option("header", True).option("inferSchema", True)
    .csv("/dbfs/FileStore/project/data/raw/transactions_incremental.csv")
    .withColumn("transaction_id", F.trim("transaction_id"))
    .withColumn("customer_id", F.trim("customer_id"))
    .withColumn("transaction_date", F.to_date("transaction_date"))
    .withColumn("amount", F.col("amount").cast("decimal(18,2)"))
    .withColumn("transaction_type", F.upper(F.trim("transaction_type")))
    .filter(F.col("transaction_id").isNotNull())
    .filter(F.col("amount") >= 0)
)

target = DeltaTable.forPath(spark, target_path)

(
    target.alias("t")
    .merge(
        new_data.alias("s"),
        "t.transaction_id = s.transaction_id"
    )
    .whenMatchedUpdateAll()
    .whenNotMatchedInsertAll()
    .execute()
)
