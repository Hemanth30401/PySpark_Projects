# PySpark + Delta Lake + SQL Database Personal Project

## Project
A simple Azure Databricks personal project that demonstrates:
- PySpark transformations
- Delta Lake Bronze/Silver/Gold tables
- Incremental MERGE/upsert
- Data quality checks
- SQL queries on Gold Delta tables
- Optional export of Gold data to a SQL database

## Architecture
Raw CSV -> Bronze Delta -> Silver Delta -> Gold Delta -> SQL/BI

## Databricks paths
For a Databricks workspace, replace local paths such as `/tmp/...` with
ADLS Gen2 / Unity Catalog managed or external locations.

## Run order
1. `01_bronze_ingestion.py`
2. `02_silver_transform.py`
3. `03_gold_aggregation.py`
4. `04_incremental_merge.py`
5. `05_data_quality.py`
6. `06_sql_database_export.py` (optional)

This is a personal interview/demo project. Production deployments would add
Unity Catalog governance, secrets, monitoring, CI/CD, orchestration, and
environment-specific configuration.
